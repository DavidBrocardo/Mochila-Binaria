import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


numeros = []
vet = []
vet2 = []

with open('bene.txt', 'r') as f:
    for linha in f:
      numeros_linha = list(map(int, linha.strip().split()))
      numeros.extend(numeros_linha)
            
print('valores do arquivo:',numeros_linha)
maxi = max(numeros_linha, key=int)
print('maior:',maxi)
a=len(numeros_linha)

for i in range(1, a+1):
  vet.append(i)
  vet2.append(maxi)
#  print(vet)
# print(vet2)
#  print(numeros_linha)

plt.title("Evolução dos beneficios")
plt.xlabel("Cada Iteração")
plt.ylabel("Beneficio")
plt.plot(vet,numeros_linha, 'k--')
plt.plot(vet,numeros_linha, 'go')
plt.plot(vet,vet2)  
plt.savefig('graff.png', format='png')
plt.show()








#https://blog.tecnospeed.com.br/graficos-em-python/
#https://www.pythonprogressivo.net/2018/10/Como-Abrir-e-Ler-Arquivos-em-Python-read-open.html
